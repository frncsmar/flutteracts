import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  ));
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String name1 = 'Gojo Satoru';
  String name2 = 'Itadori Yuuji';
  String name3 = 'Fushiguro Megumi';
  bool isFirstNames = true;

  void changeNames() {//the onpressed func will call this function when clicked
    setState(() {
      if (isFirstNames) {
        name1 = 'Sukuna';
        name2 = 'Yuuta';
        name3 = 'Ghetto';
      } else {
        name1 = 'Gojo Satoru';
        name2 = 'Itadori Yuuji';
        name3 = 'Fushiguro Megumi';
      }
      isFirstNames = !isFirstNames;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue,
      body: Container(
        padding: EdgeInsets.fromLTRB(30.0, 40.0, 30.0, 0.0),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Column(

                    children: <Widget>[
                      Icon(
                        Icons.email,
                        color: Colors.black,
                      ),
                      Container(
                        width: 150,
                        height: 100,
                        color: Colors.white,
                        child: Text(
                          name1,
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 20,
                            letterSpacing: 2.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 30.0,
                ),
                Expanded(
                  child: Column(
                    children: <Widget>[
                      Icon(
                        Icons.phone_android,
                        color: Colors.black,
                      ),
                      Container(
                        width: 150,
                        height: 100,
                        color: Colors.white,
                        child: Text(
                          name2,
                          style: TextStyle(
                            color: Colors.blue,
                            fontSize: 20,
                            letterSpacing: 2.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 30.0,
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    children: <Widget>[
                      Icon(
                        Icons.outbound,
                        color: Colors.black,
                      ),
                      Container(
                        width: 150,
                        height: 100,
                        color: Colors.white,
                        child: Text(
                          name3,
                          style: TextStyle(
                            color: Colors.amber,
                            fontSize: 20,
                            letterSpacing: 2.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          changeNames(); // functions used to change the  names
        },
        child: Icon(Icons.restart_alt_rounded, color: Colors.black,),
      ),
    );
  }
}
